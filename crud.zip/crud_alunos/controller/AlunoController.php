<?php
require_once(__DIR__ . "/config.php");
require_once(__DIR__ . "/../dao/AlunoDAO.php");
require_once(__DIR__ . "/../model/Aluno.php");

class AlunoController {

    private AlunoDAO $alunoDAO;

    public function __construct() {
        $this->alunoDAO = new AlunoDAO();        
    }

    public function listar() {
        $lista = $this->alunoDAO->listar();
        return $lista;
    }

    public function inserir(Aluno $aluno){
        $erros = [];
        $erro = $this->alunoDAO->inserir($aluno);
        if($erro)
        {
            if(AMB_DEV)
                $erros[] = $erro->getMessage();
            else
                $erros[] = "Erro ao inserir";
                return $erros;
        }
    }

}