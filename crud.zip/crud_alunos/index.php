<?php
    //Redireciona para a listagem de alunos
    header("location: ./view/alunos/listar.php");
    